========================================================================
AuraShare - Secure Offline Peer-to-Peer File Sharing Application
========================================================================

AuraShare allows devices to discover and transfer files directly across
local Wi-Fi, Ethernet, or phone hotspots with 100% offline security.
No internet connection or cloud storage is required.

QUICK START:
1. Windows:
   - Double-click 'start_windows.bat'
   - AuraShare opens in your browser at http://localhost:8080

2. macOS / Linux:
   - Run: chmod +x start_linux_mac.sh && ./start_linux_mac.sh
   - AuraShare opens at http://localhost:8080

3. Android / Mobile:
   - Connect your phone and PC to the same Wi-Fi or turn on Phone Hotspot.
   - Look at the top banner in AuraShare for the Network LAN IP (e.g. http://10.73.110.163:8080).
   - Open that URL in your mobile browser.

FEATURES:
- 100% Offline P2P Transfer (Direct TCP & Local Sockets)
- Real-time High-Graphics Radar HUD Scanner
- End-to-End Receiver Authorization
- Local Offline Vault Authentication
- Zero Cloud Traffic & SHA-256 File Integrity
========================================================================

#!/bin/bash
echo "========================================================"
echo "  Starting AuraShare Offline Application (Zero Internet)"
echo "========================================================"
python3 server.py &
SERVER_PID=$!
sleep 1
if command -v xdg-open > /dev/null; then
  xdg-open "http://localhost:8080"
elif command -v open > /dev/null; then
  open "http://localhost:8080"
fi
echo "AuraShare running on http://localhost:8080. Press Ctrl+C to stop."
wait $SERVER_PID

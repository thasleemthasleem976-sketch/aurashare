@echo off
title AuraShare Offline Server
echo ========================================================
echo   Starting AuraShare Offline Application (Zero Internet)
echo ========================================================
echo Starting local web server...
start "" "http://localhost:8080"
python server.py
pause
